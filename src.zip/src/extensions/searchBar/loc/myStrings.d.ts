declare interface ISearchBarApplicationCustomizerStrings {
  Title: string;
}

declare module 'SearchBarApplicationCustomizerStrings' {
  const strings: ISearchBarApplicationCustomizerStrings;
  export = strings;
}
