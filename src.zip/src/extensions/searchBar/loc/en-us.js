define([], function() {
  return {
    "Title": "SearchBarApplicationCustomizer"
  }
});