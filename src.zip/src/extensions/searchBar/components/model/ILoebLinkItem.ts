export interface ILoebLinkItem {
    Title: string;
    Author: string;
    Link: string;
}