export interface IExperienceItem {
    Title: string; 
    Abstract: string;
    Disclosure: string;
    Attorneys: string;
}